<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h1 style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:xx-large; font-weight:600;&quot;&gt;Red Panda C++&lt;/span&gt;&lt;/h1&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Based on Qt %1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build time: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright(C) 2021-2022 瞿华(royqh1979@gmail.com)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Homepage: &lt;a href=&quot;Homepage: https://sourceforge.net/projects/dev-cpp-2020/&quot;&gt;https://sourceforge.net/projects/dev-cpp-2020/&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GNU General Public License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along with this program.  If not, see &lt;https://www.gnu.org/licenses/&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-GCC Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Website: &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Generation Microsoft Visual C++</source>
        <translation>下一代 Microsoft Visual C++</translation>
    </message>
    <message>
        <source>Microsoft Visual C++ 2022</source>
        <translation>Microsoft Visual C++ 2022</translation>
    </message>
    <message>
        <source>Microsoft Visual C++ 2019</source>
        <translation>Microsoft Visual C++ 2019</translation>
    </message>
    <message>
        <source>Microsoft Visual C++ 2017</source>
        <translation>Microsoft Visual C++ 2017</translation>
    </message>
    <message>
        <source>Legacy Microsoft Visual C++</source>
        <translation>舊版 Microsoft Visual C++</translation>
    </message>
</context>
<context>
    <name>AppTheme</name>
    <message>
        <source>Theme file &apos;%1&apos; doesn&apos;t exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error in json file &apos;%1&apos;:%2 : %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open the theme file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutolinkModel</name>
    <message>
        <source>Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BacktraceModel</name>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarkModel</name>
    <message>
        <source>Save file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error in json file &apos;%1&apos;:%2 : %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BreakpointModel</name>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CPUDialog</name>
    <message>
        <source>CPU Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step over one machine instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step into one machine instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AT&amp;&amp;T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blend Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Callstack</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChooseThemeDialog</name>
    <message>
        <source>Choose Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Theme</source>
        <translation>深色主題</translation>
    </message>
    <message>
        <source>Light Theme</source>
        <translation>淺色主題</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Theme</source>
        <translation>跟隨系統樣式和顏色</translation>
    </message>
</context>
<context>
    <name>CodeSnippetsManager</name>
    <message>
        <source>Load default code snippets failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t copy default code snippets &apos;%1&apos; to &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read code snippets failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open code snippet file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read code snippet file &apos;%1&apos; failed:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save code snippets failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open code snippet file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write to code snippet file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load new file template failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open new file template file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save new file template failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open new file template file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CodeSnippetsModel</name>
    <message>
        <source>Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completion Prefix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu Section</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorEdit</name>
    <message>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Compiler</name>
    <message>
        <source>Clean before rebuild failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile Result:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Errors: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Warnings: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Output Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Output Size: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compilation Time: %1 secs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Error] </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Warning] </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Info] </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Note] </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler process for &apos;%1&apos; failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler process crashed after starting successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The last waitFor...() function timed out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to write to the compiler process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to read from the compiler process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An unknown error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Command: %1 %2 &gt; &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &quot;%1&quot; for write!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CompilerAutolinkWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable auto link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CompilerManager</name>
    <message>
        <source>No compiler set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No compiler set is configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t start debugging.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find Console Pauser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Console Pauser &quot;%1&quot; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CompilerSetDirectoriesWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CompilerSetOptionWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler set to config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Find Compilers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Compiler in the Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Blank Compiler Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert Executable&apos;s Charset as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statically link libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add the following arguments when calling the compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add the following arguments when calling the linker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose make</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Compiler(gcc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Compiler(g++)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose C++ Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>make</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose C Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gdb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Resource Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gdb server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resource Compiler（windres)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Red Panda C++ will clear previously found compiler list and search for compilers in the following locations:&lt;br /&gt; &apos;%1&apos;&lt;br /&gt; &apos;%2&apos;&lt;br /&gt;Do you really want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Red Panda C++ will clear previously found compiler list and search for compilers in the the PATH. &lt;br /&gt;Do you really want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find any compiler.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Set Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Set Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compilation Stages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop after the preprocessing stage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop after the compilation proper stage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link and generate the executable </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preprocessing output suffix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiling output suffix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable suffix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate C Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable files (*.exe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate C++ Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate Make</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate GDB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate GDB Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate windres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searching for compilers...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Binary suffix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Survive auto-finds</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CppRefacter</name>
    <message>
        <source>Rename Symbol Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t rename symbols not defined in this file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New symbol already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomMakefileInfoDialog</name>
    <message>
        <source>Information for custom makefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Red Panda C++&apos;s Makefile has two important targets:&lt;/p&gt;&lt;p&gt;- all (which builds the executable)&lt;/p&gt;&lt;p&gt;- clean (which cleans up object files)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&amp;quot;all&amp;quot; depends on 2 targets: all-before and all-after. All-before&lt;/p&gt;&lt;p&gt;gets called before the compilation process, and all-after gets&lt;/p&gt;&lt;p&gt;called after the compilation process.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&amp;quot;clean&amp;quot; depends on the target clean-custom, which gets called&lt;/p&gt;&lt;p&gt;before the cleaning process.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;You can change the Makefile&apos;s behavior by defining the targets&lt;/p&gt;&lt;p&gt;that &amp;quot;all&amp;quot; and &amp;quot;clean&amp;quot; depend on.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DebugGeneralWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use GDB Server to debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GDB Server Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show only monospaced fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show detail debug logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show CPU Window when signal received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CPU Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disassembly Coding Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AT&amp;&amp;T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show disassembly code in blend mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autosave watches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max number of array elements displayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip header files when step into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max  characters of a string displayed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Debugger</name>
    <message>
        <source>No compiler set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No compiler set is configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t start debugging.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugger not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GDB Server path error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GDB Server&apos;s path &quot;%1&quot; contains non-ascii characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This prevents it from executing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GDB Server not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;&apos;t find gdb server in : &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute to evaluate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source file is more recent than executable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recompile?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signal &quot;%1&quot; Received: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error in json file &apos;%1&apos;:%2 : %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;&apos;t find debugger (gdb) in : &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the &quot;program&quot; page of compiler settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Editor</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File %1 already opened!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text to be copied exceeds count limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text to be copied exceeds character limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text to be cut exceeds count limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The text to be cut exceeds character limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+click for more info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>astyle not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find astyle in &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break point condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the condition of the breakpoint:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Readonly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Load File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hex: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dec: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorAutoSaveWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable auto save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Objects to save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save strategy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append UNIX timestamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append formatted timestamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo file name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo file name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto backup editing contents</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorClipboardWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy Size Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t copy text larger than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size(kilo characters):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy with format as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy &amp;&amp; Export As HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use background color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use editor&apos;s color scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export As RTF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorCodeCompletionWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable code competion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum id length to show completion </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear all parsed symbols when editor is hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show completion suggestions while typing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Engine options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scan local header files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scan system header files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show keywords in suggestions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show code snippets in suggestions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Append () when complete functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore case when search suggestions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefer local symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide symbols start with underscore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide symbols start with two underscores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefer symbols mostly used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear usage data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completion suggestion window width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completion suggestion window height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editors share one code parser</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorColorSchemeWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Foreground:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Styles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underlined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rainbow parenthesis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore to Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Scheme...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Scheme Files (*.scheme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid name for color scheme file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New scheme name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid scheme name!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Delete Scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scheme &apos;%1&apos; will be deleted!&lt;br /&gt;Do you really want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorFontWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show only monospaced fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font for non-ascii Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gutter is visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Line Numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add leading zeros to line numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line numbers starts at zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto calculate the digit count of line number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digit count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Custom Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable ligatures support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show whitespaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trailing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line break</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorGeneralWidget</name>
    <message>
        <source>Vertical Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Half Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorMiscWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open system header files in read only mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto load files being open when Red Panda C++ last exited.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto detect encoding when openning files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default file encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default file type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8 BOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parse TODOs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory Usage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Steps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action before saving files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limits for Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reformat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim trailing spaces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorSnippetWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code Snippets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New C File Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New C++ File Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New GAS File Template</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorSymbolCompletionWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Braces{}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Brackets []</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Parenthesis ()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Multiline Comments /**/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Single Quotations &apos;&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Double Quotations &quot;&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete #include &lt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skip matching symbols while typing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove symbol pairs when delete chars</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorSyntaxCheckWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Auto Syntax Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check when save/load file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check when count of lines changed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorTooltipsWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show function tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable mouse hover tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show syntax issue tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show full header filename tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show identifier definition tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show expression value tooltips when debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool tips delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentAppearanceWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*Needs restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Theme:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use custom theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon Set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use custom icon set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon Zoom:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentFileAssociationWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Each File In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Independent Red Panda C++ applications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The same Red Panda C++ application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Types:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Just check or uncheck for which file types Red Panda C++ wil be registered as the default application to open them ... </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentFoldersWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom icon sets folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all custom settings and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom theme folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open custom theme folder in file browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete all custom settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to delete custom settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentPerformanceWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reduce Memory Usage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto clear parsed symbols when editor hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editors share one code parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max undo memory for each editor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentProgramsWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Terminal Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Detect Terminal Arguments Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use custom terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Args. pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cmd. preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentShortcutModel</name>
    <message>
        <source>action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut &quot;%1&quot; is used by &quot;%2&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvironmentShortcutWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyword</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecutableRunner</name>
    <message>
        <source>The runner process &apos;%1&apos; failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The last waitFor...() function timed out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to write to the runner process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to read from the runner process.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecutorGeneralWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause console programs after return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimize IDE when running programs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters to pass to your program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redirect input to the following file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugger doesn&apos;t support this feature in Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugger only support this feature in gdb server mode in windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose input file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parsed argv array (represented in JSON):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable ANSI Escape Sequences Support</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExecutorProblemSetWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listen for Competitive Companion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Case Editor Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only Monospaced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Case Valdation Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>kb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert HTML for：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expected Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redirect STDERR to Tools output panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Case Validate type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore leading/trailing spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore spaces</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileAssociationModel</name>
    <message>
        <source>Register File Association Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t have privilege to register file types!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register File Type Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileCompiler</name>
    <message>
        <source>Compiling single file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compiler Set Name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t delete the old executable file &quot;%1&quot;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find the compiler for file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Compiler &apos;%1&apos; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing %1 source file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Compiler: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the &quot;program&quot; page of compiler settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checking single file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GNU Assembler</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <source>File Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative to Project:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Including files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Characters:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormatterGeneralWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Predefined format style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Note for the predefined format style&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brace modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach braces to namespace statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach braces to classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach braces to class inline function definitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach braces to extern &quot;C&quot; statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach the closing while of do-while to the close brace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert tabs to the appropriate number of spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indentation 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent using spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent using tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent for continuation lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimal indent for a continuous conditional beloning to a conditional header:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximal indent spaces for a continuation line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indentation 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent class blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent namespaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent class access modifiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent after parenthesis &apos;(&apos; or assignment &apos;=&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent preprocessor conditional statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent multi-line preprocessor #define statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent line comments that start in column one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent preprocessor blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent switch blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent cases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Padding 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces around operators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces after commas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces after parenthesis headers (&apos;if&apos;,&apos;for&apos;,...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces around parenthesis on the outside only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces around parenthesis on the inside only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert empty lines arround unrelated blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert empty lines around all blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces around first parenthesis in a series on the out side  only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert spaces around parenthesis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Padding 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all empty lines. It will NOT delete lines added by the padding options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach a pointer operator to its :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all consecutive empty lines. It will NOT delete lines added by the padding options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>type(left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill empty lines with the white space of the previous lines.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>name(right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove unnecessary space adding around parenthesis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach a reference operator to its :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break one line headers (&apos;if&apos;,&apos;while&apos;,&apos;else&apos;...) from the statement on the same line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add one line braces to unbraced one line conditional statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break braces before close headers (&apos;else&apos;,&apos;catch&quot;...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove braces from a braced one line conditional statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break &apos;else if&apos; statements into two lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add braces to unbraced one line conditional statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break return type from the function name in its definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t break blocks residing completely on one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach return type to the function name in its definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t break multiple statements residing on one line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break return type from the function name in its declaration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach return type to the function name in its declaration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break lines exceeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the leading &apos;*&apos; prefix on multi-line comments and indent the comment text one line indent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close ending angle brackets on template definitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Place the logical conditional to the last on the previous line, when break lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No minimal indent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent at least one additional indent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent at least two additional indents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent at least one-half an additional indent.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormatterPathWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to astyle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormatterStyleModel</name>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The opening braces will not be changed and closing braces will be broken from the preceding line.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allman</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Broken braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Java</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attached braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K&amp;R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stroustrup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces, with broken closing headers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whitesmith</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Broken, indented braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indented class blocks and switch blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VTK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Broken, indented braces except for the opening braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ratliff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attached, indented braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GNU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Broken braces, indented blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces, minimum conditional indent is one-half indent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horstmann</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run-in braces, indented switches.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One True Brace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces, add braces to all conditionals.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Google</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attached braces, indented class modifiers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mozilla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces, with broken braces for structs and enums, and attached braces for namespaces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Webkit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linux braces, with attached closing headers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run-in opening braces and attached closing braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uses keep one line blocks and keep one line statements.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lisp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attached opening braces and attached closing braces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uses keep one line statements.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitBranchDialog</name>
    <message>
        <source>Branch/Switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overwrite working tree changed(force)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pass --track to git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pass --no-track to git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force No Track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neither --track nor --no-track is passed to git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not Specifiied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create New Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge between original branch, working tree contents and the branch to switch to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Force Creation (Reset branch if exists)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitFetchDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitLogDialog</name>
    <message>
        <source>Git Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset &quot;%1&quot; to this...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revert &quot;%1&quot; to this...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Branch at this version...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Tag at this version...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitLogModel</name>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitManager</name>
    <message>
        <source>Folder &quot;%1&quot; already has a repository!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitMergeDialog</name>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Squash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Fast Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast Forward Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitPullDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitPushDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitRemoteDialog</name>
    <message>
        <source>Git Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitResetDialog</name>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset current branch &quot;%1&quot; to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Branch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Leave working tree and index untouched&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reset working tree and index (discarding local changes)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leave working tree untouched, reset index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GitUserConfigDialog</name>
    <message>
        <source>Fill User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Git needs the following info to commit：</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoMessageBox</name>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IssuesModel</name>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Col</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IssuesTable</name>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Col</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LanguageAsmGenerationWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t generate debug directives</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t generate SEH directives </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AT&amp;&amp;T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instruction syntax:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t generate cli directives.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacroInfoModel</name>
    <message>
        <source>The default directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to the Red Panda C++&apos;s executable file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version of the Red Panda C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PATH to the Red Panda C++&apos;s installation folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current date and time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The first include directory of the working compiler set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The first lib directory of the working compiler set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiled filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full path to the compiled file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename of the current source file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full path to the current source file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to the current source file&apos;s parent folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word at the cursor in the active editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full path to the current project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of the current project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to the current project&apos;s folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Red Panda C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Evaluate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Call Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Breakpoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address Expression:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TODO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Probem Case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Problem Case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Anwser Source File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run All Cases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Cases Validation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%v/%m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Input File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refactor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tool Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Source File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UnIndent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uncollapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encode in ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encode in UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert to ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert to UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rebuild All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop Execution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run To Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Watch...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View CPU Window...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find in Files...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Watch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove All Watches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Watch...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reformat Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximize Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear all breakpoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Breakpoint property...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Declaration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find references</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open containing folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a terminal here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Project...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Project File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to project...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove from project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View Makefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Folder in Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open In Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+F6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export As RTF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export As HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move To Other View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EGE Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Bookmark Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate in Files View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Working Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running Parameters...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Tool Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete to EOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete to BOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Backspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete To Word Begin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete to Word End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Class...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Header...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Git Repository</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Branch/Switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remotes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fetch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pull</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Non Support Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Block Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alt+Shift+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Match Bracket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Selection Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Selection Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Snippet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Theme Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source file is not compiled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No compiler set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No compiler set is configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t start debugging.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host applcation missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLL project needs a host application to run.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>But it&apos;s missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host application not exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host application file &apos;%1&apos; doesn&apos;t exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Save Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto save &quot;%1&quot; to &quot;%2&quot; failed:%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save last open info error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save last open info file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load last open info error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t load last open info file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Source File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run Current Case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Batch Set Cases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove All Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show detail debug logs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear all searches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Breakpoint condition...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove All Breakpoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch to normal view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch to custom view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort By Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort alphabetically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show inherited members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto declaration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in External Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in Windows Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Character sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Convertion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The editing file will be saved using %1 encoding. &lt;br /&gt;This operation can&apos;t be reverted. &lt;br /&gt;Are you sure to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 files autosaved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set answer to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select other file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Answer Source File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C/C++ Source Files (*.c *.cpp *.cc *.cxx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This operation will remove all cases for the current problem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to do that?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose input files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input data files (*.in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Case %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Folder %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete %1 files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Problem Set Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Set Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmark Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Break point condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the condition of the breakpoint:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The project &apos;%1&apos; has modifications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to save it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; was changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload its content from disk?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; was removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep it open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Project File?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to add the new file to the project?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Project Compiler Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the project&apos;s compiler set will lose all custom compiler set options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Watch Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Watch Expression (it is recommended to use &apos;this-&gt;&apos; for class members):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parsing file %1 of %2: &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Done parsing %1 files in %2 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(%1 files per second)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to clear all breakpoints in this file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close %1 and start new project?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder &apos;%1&apos; doesn&apos;t exist. Create it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t create folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create folder &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save new project as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Red Panda C++ project file (*.dev)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New project fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t assign project template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the file from disk?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Project File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Already Exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder %1 is not empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol &apos;%1&apos; is defined in system header.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for replace!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents has changed since last search!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rich Text Format Files (*.rtf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTML Files (*.html)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change working folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; is not in the current working folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to change working folder to &apos;%1&apos;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current problem set is not empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Set Files (*.pbs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header file &quot;%1&quot; already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source file &quot;%1&quot; already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t commit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following files are in conflicting:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commit message shouldn&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Git needs user info to commit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Input Data File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Expected Output Data File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert to UTF-8 BOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encode in UTF-8 BOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Explorer Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Messages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify Watch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watch Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raylib Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go to Line...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go to Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Template...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Template from Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Template Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Template %1 already exists. Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrong Compiler Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler is set not to generate executable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We need the executabe to run problem case.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please correct this before start debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open last open information file &apos;%1&apos; for write!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto block start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto block end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Alt+Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch header/source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch Header/Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generate Assembly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import FPS Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FPS Problem Set Files (*.fps;*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim trailing spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export FPS Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FPS Problem Set Files (*.fps)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Expected Output File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Problem Case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Readonly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line: %1 Col: %2 Lines: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Newline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open file in editors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit Issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New C/C++ File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New GAS File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to generate the executable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check detail info in &quot;Tools Output&quot; panel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GNU Assembler Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The executable doesn&apos;t have symbol table, and can&apos;t be debugged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x86 Assembly Language Reference Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IA-32 Assembly Language Reference Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Watchpoint...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a watchpoint that&apos;s triggered when it&apos;s modified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Old value: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watchpoint variable name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop execution when the following variable is modified (it must be visible from the currect scope):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watchpoint hitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value of &quot;%1&quot; has changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New value: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Text File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing Project Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following files is missing, can&apos;t build the project:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save settings failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project folder removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder for project &apos;%1&apos; was removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It will be closed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+K, Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correct compile settings for debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The generated executable won&apos;t have debug symbol infos, and can&apos;t be debugged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Or you can manually change the following settings in the options dialog&apos;s compiler set page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Turned on the &quot;Generate debug info (-g3)&quot; option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Turned off the &quot;Strip executable (-s)&quot; option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Turned off the &quot;Optimization level (-O)&quot; option or set it to &quot;Debug (-Og)&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you are using the Release compiler set, please use choose the Debug version from toolbar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to mannually change the compiler set settings now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You should recompile after change the compiler set or it&apos;s settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto File Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto File End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Up and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Down and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Page Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Page End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Page Start and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Page End and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line Start and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto Line End and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto File Start and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto File End and Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Others</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OI Wiki</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turtle Graphics Tutorial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore leading/trailing spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder Not Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The project folder is not empty, existing files may be overwritten.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line: %1 Col: %2 Sel:%3 Lines: %4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MemoryModel</name>
    <message>
        <source>ascii: &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dec: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>oct: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bin: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>addr: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewClassDialog</name>
    <message>
        <source>New Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base Class:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewHeaderDialog</name>
    <message>
        <source>New Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewProjectDialog</name>
    <message>
        <source>New Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make default language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use as the default project location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon Info:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewProjectUnitDialog</name>
    <message>
        <source>New Project Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewTemplateDialog</name>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Template From Project</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OJProblemCasesRunner</name>
    <message>
        <source>The runner process &apos;%1&apos; failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The last waitFor...() function timed out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to write to the runner process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred when attempting to read from the runner process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time limit exceeded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory limit exceeded!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OJProblemModel</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time(ms)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory(kb)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OJProblemPropertyWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Project</name>
    <message>
        <source>Error Load File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; is already in the project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your project was succesfully updated to a newer file format!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If something has gone wrong, we kept a backup-file: &apos;%1&apos;...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Others</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings need update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler settings format of Red Panda C++ has changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please update your settings at Project &gt;&gt; Project Options &gt;&gt; Compiler and save your project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The compiler set you have selected for this project, no longer exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It will be substituted by the global compiler set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Developed using the Red Panda C++ IDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t create folder %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save file %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectAlreadyOpenDialog</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Projects can either be opened in a new window or replace the project in the existing window or be attached to the already opened projects. How would you like to open the project?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;This Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New &amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Project</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectCompileParamatersWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Library Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Library Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel Jobs(0 means infinite):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resource</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectCompiler</name>
    <message>
        <source>Building makefile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open &apos;%1&apos; for write!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Resource File: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiling project changes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Project Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compiler Set Name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing makefile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- makefile processer: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make program &apos;%1&apos; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the &quot;program&quot; page of compiler settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectCompilerWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base compiler set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customize (apply to this project only):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statically link libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Encoding for the executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrong Compiler Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler %1 can&apos;t compile a microcontroller project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler %1 can only compile microcontroller project.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Project Compiler Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change the project&apos;s compiler set will lose all custom compiler set options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to do that?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectDLLHostWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host application for DLL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose host application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectDirectoriesWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Includes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Binaries</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectFilesWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include in compilation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include in linking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile files as C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Override build command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project(%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectGeneralWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default encoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Win32 GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Win32 Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Win32 Static Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Win32 DLL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default to C++ when creating new files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Support Windows XP Themes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 files [ %2 sources, %3 headers, %4 resources, %5 other files ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t remove old icon file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t remove old icon file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select icon file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.ico *.png *.jpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ANSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UTF-8 BOM</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectMakefileWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use custom make file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Information about using a custom make file </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include the following files into the makefile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom makefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectModel</name>
    <message>
        <source>File exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File &apos;%1&apos; already exists. Delete it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to remove file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to rename file &apos;%1&apos; to &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectOutputWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object file output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto save compile log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Override output filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object files output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectPreCompileWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use precompiled header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;For more information about gcc precompiled header, see:&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://gcc.gnu.org/onlinedocs/gcc/Precompiled-Headers.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;https://gcc.gnu.org/onlinedocs/gcc/Precompiled-Headers.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the header file to be precompiled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header files (*.h *.hh *.hpp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header to be precompiled:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectTemplate</name>
    <message>
        <source>Read failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t read template file &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t Open Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open template file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Old version template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Template file &apos;%1&apos; has version &apos;%2&apos;, which is unsupported.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectVersionInfoWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include version info in project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Major</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rlease</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sync product with file version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legal trademarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Company name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-increase build number on compile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legal copyright</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t parse json file &apos;%1&apos; at offset %2! Error Code: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t parse json file &apos;%1&apos; is not a color scheme config file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &apos;%1&apos; for write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t Find the color scheme file %1!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t remove the color scheme file %1!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Float</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gloabal Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hexadecimal Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Illegal Char</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Octal Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preprocessor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reserve Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escape Sequences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brace/Bracket/Parenthesis Level 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brace/Bracket/Parenthesis Level 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brace/Bracket/Parenthesis Level 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brace/Bracket/Parenthesis Level 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gutter Active Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fold Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Highlighted Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename file &apos;%1&apos; to &apos;%2&apos; failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scheme &apos;%1&apos; already exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t create configuration folder %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t write to configuration file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t load autolink settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>constructor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>destructor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code Generation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable use of specific instructions (-mx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optimization level (-Ox)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile with the following pointer size (-mx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inhibit all warning messages (-w)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show most warnings (-Wall)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show some more warnings (-Wextra)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only check the code for syntax errors (-fsyntax-only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make all warnings into errors (-Werror)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort compilation on first error (-Wfatal-errors)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generate profiling info for analysis (-pg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not use standard system libraries (-nostdlib)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not create a console window (-mwindows)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strip executable (-s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generate debugging information (-g3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use pipes instead of temporary files during compilation (-pipe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler set not configuared.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Would you like Red Panda C++ to search for compilers in the following locations: &lt;BR /&gt;&apos;%1&apos;&lt;BR /&gt;&apos;%2&apos;? </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Would you like Red Panda C++ to search for compilers in PATH?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Binaries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Libraries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Includes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Includes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dev C++ Project files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;Auto Generated by Git&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t parse problem set file &apos;%1&apos;:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C++ Language standard (-std)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C Language standard (-std)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reserve Word for Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Case %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &quot;%1&quot; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open file &quot;%1&quot; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error when writing file &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to remove &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GAS files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lua files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for stack smashing attacks (-fstack-protector)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check ISO C/C++ conformance (-pedantic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Sanitizer (-fsanitize=)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processor (-m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language standard (--std)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t generate startup code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use external stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use movc instead of movx to read from external ram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t memcpy initialized xram from code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MCU Specification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal ram size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>External ram start location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>External ram size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stack pointer initial value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>External stack start location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct data start location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code segment location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code segment size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory model (--model)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replaces lcall/ljmp with acall/ajmp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Detection Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to detect terminal arguments pattern for “%1”.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegisterModel</name>
    <message>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>64-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General purpose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>128-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point tag word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSE status and control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accumulator for operands and results data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pointer to data in the DS segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Counter for string and loop operations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I/O pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source index for string operations; Pointer to data in the segment pointed to by the DS register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination index for string operations; Pointer to data (or destination) in the segment pointed to by the ES register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stack pointer (in the SS segment)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pointer to data on the stack (in the SS segment)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code segment selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data segment selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extra data segment selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point last instruction segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point last instruction offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point last operand segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating-point last operand offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instruction pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lower 16 bits of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lower 8 bits of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8 high bits of lower 16 bits of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stack segment selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>256-bit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SDCCFileCompiler</name>
    <message>
        <source>Compiling single file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compiler Set Name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find &quot;%1&quot;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Compiler &apos;%1&apos; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the &quot;program&quot; page of compiler settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing %1 source file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- %1 Compiler: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t delete the old executable file &quot;%1&quot;.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SDCCProjectCompiler</name>
    <message>
        <source>Building makefile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open &apos;%1&apos; for write!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiling project changes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Project Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compiler Set Name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make program &apos;%1&apos; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please check the &quot;program&quot; page of compiler settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing makefile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- makefile processer: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <source>Text to Find:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regular Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrap Around</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scope:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Origin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entire scope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End of file has been reached. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to continue from file&apos;s beginning?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close after search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beginning of file has been reached. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to continue from file&apos;s end?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchInFileDialog</name>
    <message>
        <source>Text to Find:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Where:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files In Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regular Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search in Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searching...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*.*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search in subfolders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchResultListModel</name>
    <message>
        <source>Current File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files In Project:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Usages in Current File: &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Usages in Project: &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;%1&quot; in Folder &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchResultTreeModel</name>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchResultTreeViewDelegate</name>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find terminal program!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program Runner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy &amp; Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code Completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Symbol Completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Snippet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Syntax Checking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code Formatter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Compile options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precompiled Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Makefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLL host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are changes in the settings, do you want to save them before swtich to other page?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom C/C++ Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folders / Restore Default Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ASM Generation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsWidget</name>
    <message>
        <source>Load Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutManager</name>
    <message>
        <source>Read shortcut config failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open shortcut config file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read shortcut config file &apos;%1&apos; failed:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save shortcut config failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open shortcut config file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write to shortcut config file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignalMessageDialog</name>
    <message>
        <source>Signal Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open CPU Info Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StdinCompiler</name>
    <message>
        <source>Checking file syntax...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Filename: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Compiler Set Name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find the compiler for file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Compiler &apos;%1&apos; doesn&apos;t exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing %1 source file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Compiler: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Command: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiling...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SymbolUsageManager</name>
    <message>
        <source>Load symbol usage info failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open symbol usage file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t parse symbol usage file &apos;%1&apos;: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save symbol usage info failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open symbol usage file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write to symbol usage file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TodoModel</name>
    <message>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsGeneralWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause console after the program exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Working Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Macro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable files (*.exe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to save changes to &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title shouldn&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsGitWidget</name>
    <message>
        <source>Git</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to Git Executable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Git Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolsManager</name>
    <message>
        <source>Remove Compiled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read tools config failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open tools config file &apos;%1&apos; for read.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read tools config file &apos;%1&apos; failed:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save tools config failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t open tools config file &apos;%1&apos; for write.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write to tools config file &apos;%1&apos; failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatchModel</name>
    <message>
        <source>Not Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute to evaluate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>editorcustomctypekeywords</name>
    <message>
        <source>Custom C/C++ Type Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Custom C/C++ Type Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: Custom keywords is not recognized by syntax checker.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>editorgeneralwidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Indent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace tab with spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Indent Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indent Line Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill Indents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caret</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move caret to the first non-space char in the current line when press HOME key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move caret to the last non-space char in the current line when press END key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep X position of the caret when moving vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caret for inserting mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caret Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Caret for overwriting mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use text color as caret color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight matching braces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight current word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto hide scroll bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can scroll the last char to the left edge of the editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can scroll the last line to the top edge of the editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Up/Down scrolls half a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forces page scroll to be one line less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Wheel Scroll Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Selection/Dragging Scroll Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show right edge line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right egde width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right edge line color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
